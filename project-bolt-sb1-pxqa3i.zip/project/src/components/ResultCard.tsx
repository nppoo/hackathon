import React from 'react';
import { Shield, ShieldAlert } from 'lucide-react';

interface ResultCardProps {
  result: {
    isReal: boolean;
    confidence: number;
    type: string;
  };
}

export function ResultCard({ result }: ResultCardProps) {
  const { isReal, confidence, type } = result;

  return (
    <div className="w-full max-w-md p-6 bg-white rounded-xl shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-semibold text-gray-800">Analysis Result</h3>
        {isReal ? (
          <Shield className="w-8 h-8 text-green-500" />
        ) : (
          <ShieldAlert className="w-8 h-8 text-red-500" />
        )}
      </div>
      
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <span className="text-gray-600">Authenticity:</span>
          <span className={`font-medium ${isReal ? 'text-green-600' : 'text-red-600'}`}>
            {isReal ? 'Authentic' : 'Potentially Manipulated'}
          </span>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-gray-600">Confidence:</span>
          <span className="font-medium text-blue-600">{confidence}%</span>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-gray-600">Media Type:</span>
          <span className="font-medium text-gray-800">{type}</span>
        </div>
        
        <div className="w-full bg-gray-200 rounded-full h-2.5 mt-4">
          <div 
            className={`h-2.5 rounded-full ${isReal ? 'bg-green-600' : 'bg-red-600'}`}
            style={{ width: `${confidence}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
}